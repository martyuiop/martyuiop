# Image Sources

## Everaldo Coelho

* Images: document.png, trash.png
* License: GPL/LGPL
* Url: http://www.everaldo.com


## LazyCrazy - Very Emotional

* Images: smileys
* License: Free for commercial use
* Url: http://lazycrazy.deviantart.com/